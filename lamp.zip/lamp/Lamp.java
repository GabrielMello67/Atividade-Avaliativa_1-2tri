package avaliacao.lamp;

public class Lamp{

    //Atributo que controla se a lampada esta acesa(true) ou apagada(false)
    private boolean ligada;
    //Atributo para definir a quantidade de potencia da lampada
    private int potencia;

    //Construtor de Lamp com potencia padrao de 60, e recebe de parametro o seu estado inicial(acesa/true ou apagada/false)
    public Lamp(boolean estadoInicial){

        ligada = estadoInicial;
        potencia = 60;

    }

    //Construtor de Lamp com que recebe de parametro o seu estado inicial(acesa/true ou apagada/false) e potencia(potencia)
    public Lamp(boolean estadoInicial, int potencia){

        ligada=estadoInicial;
        this.potencia=potencia;
    }

    //Metodo get, que retorna estado da lampada(acesa/true ou apagada/false)
    public boolean getState(){
        return ligada;
    }

    //Metodo set, que altera o estado da lampada
    public void setState(boolean alterarEstado) {
        if (alterarEstado) {
            ligada = !ligada;
            System.out.print("A lampada agora está ");
        }
        else{
            System.out.print("A lampada continuará ");
        }

    }

    //Metodo utilizado para mostrar estado da lampada
    public void showState(boolean ligada){

        if(ligada){
            System.out.println("acesa");
        }
        else if(!ligada){
            System.out.println("apagada");
        }

    }

    //Metodo get, que retorna a quantidade de potencia da lampada
    public int getWatts() {
        return potencia;
    }

    //Metodo set, que altera a quantidade de potencia da lampada
    public void setWatts(int potencia) {
        this.potencia = potencia;
    }
}
