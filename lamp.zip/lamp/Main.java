package avaliacao.lamp;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Atributo utilizado para leitura de estado inicial da luz
        boolean estadoInicial;
        //Atributo utilizado para escolher qual construtor utilizar(com watts padrao ou watts definido pelo usuario)
        boolean usarPotenciaInformada;

        //Scanner para leitura de dados
        Scanner leitor = new Scanner(System.in);

        //Definir estado inicial da luz
        System.out.print("Informe o estado inicial da luz(true/false)\n--> ");
        estadoInicial = leitor.nextBoolean();

        //Pergunta para definir qual construtor utilizar/se o usuario que informar a quantidade de watts
        System.out.print("Você quer especificar a quantidade de watts?(true/false)\n-->");
        usarPotenciaInformada = leitor.nextBoolean();

        //if-else para escolher construtor a partir da varial chooseConstrutor
        if(usarPotenciaInformada){ //Cria uma Lamp com watts lidos do usuario

            //leitura de dados
            int potenciaEscolhida;
            System.out.println("Informe a quantidade de watts que luz terá: ");
            potenciaEscolhida = leitor.nextInt();

            //Criando objeto
            Lamp luz = new Lamp(estadoInicial,potenciaEscolhida);
            luz.showState(luz.getState());
            System.out.println(luz.getWatts() + "W");

            //Troca estado da luz se o usuario quiser
            System.out.print("Você quer mudar o estado da luz?(true/false)\n--> ");
            luz.setState(leitor.nextBoolean());

            //Mostra estado da luz
            luz.showState(luz.getState());
        }
        else { //Cria uma Lamp com watts padrao de 60
            Lamp luz = new Lamp(estadoInicial);
            luz.showState(luz.getState());
            System.out.println(luz.getWatts() + "W");

            //Troca estado da luz se o usuario quiser
            System.out.print("Você quer mudar o estado da luz?(true/false)\n--> ");
            luz.setState(leitor.nextBoolean());

            //Mostra estado da luz
            luz.showState(luz.getState());
        }


    }
}
