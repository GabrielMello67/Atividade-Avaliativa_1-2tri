package avaliacao.f1;

public class Person {
    protected String nomePessoa;
    protected int idadePessoa;
    protected String paisOrigem;

    public Person(String nomePessoa, int idadePessoa, String paisOrigem){
        this.nomePessoa=nomePessoa;
        this.idadePessoa=idadePessoa;
        this.paisOrigem=paisOrigem;
    }

    public String getName() {
        return nomePessoa;
    }

    public int getAge() {
        return idadePessoa;
    }

    public String getNationality() {
        return paisOrigem;
    }

    public void setName(String nomePessoa) {
        this.nomePessoa = nomePessoa;
    }

    public void setAge(int idadePessoa) {
        this.idadePessoa = idadePessoa;
    }

    public void setNationality(String paisOrigem) {
        this.paisOrigem = paisOrigem;
    }
}
