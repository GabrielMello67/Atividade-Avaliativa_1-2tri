package avaliacao.f1;

public class Pilot extends Person {

    private int vitorias;

    public Pilot(String name, int age, String nationality, int vitorias){
        super(name, age, nationality);
        this.vitorias=vitorias;
    }

    public int getVictory() { return vitorias; }

    public void setVictory(int vitorias) { this.vitorias = vitorias; }
}
