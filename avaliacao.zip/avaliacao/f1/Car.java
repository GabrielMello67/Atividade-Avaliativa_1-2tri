package avaliacao.f1;

public class Car {

    private int numeroCarro;
    private int posicaoAtual;
    private Team equipe;
    private Pilot piloto;
    private Engineer engenheiro;

    public Car(){

    }

    public Car(int numeroCarro, int posicaoAtual, Team equipe, Pilot piloto, Engineer engenheiro){
        this.numeroCarro=numeroCarro;
        this.posicaoAtual=posicaoAtual;
        this.equipe=equipe;
        this.piloto=piloto;
        this.engenheiro=engenheiro;
    }

    public int getNumber(){
        return numeroCarro;
    }

    public int getPosition(){
        return posicaoAtual;
    }

    public Team getTeam(){
        return equipe;
    }

    public Pilot getPilot(){
        return piloto;
    }

    public Engineer getEngineer() { return engenheiro; }

    public void setNumber(int numeroCarro) {
        this.numeroCarro = numeroCarro;
    }

    public void setPosition(int posicaoAtual) {
        this.posicaoAtual = posicaoAtual;
    }

    public void setPilot(Pilot piloto) {
        this.piloto = piloto;
    }

    public void setTeam(Team equipe) {
        this.equipe = equipe;
    }
}
