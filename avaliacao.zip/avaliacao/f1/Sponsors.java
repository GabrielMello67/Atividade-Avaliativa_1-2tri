package avaliacao.f1;

public class Sponsors {

    private String nomeEmpresa;
    private double valorAnuncio;

    public Sponsors(String nomeEmpresa, double valorAnuncio){
        this.nomeEmpresa=nomeEmpresa;
        this.valorAnuncio=valorAnuncio;
    }

    public String getName() {
        return nomeEmpresa;
    }

    public double getAdValue() {
        return valorAnuncio;
    }

    public void setName(String nomeEmpresa) {
        this.nomeEmpresa = nomeEmpresa;
    }

    public void setAdValue(double valorAnuncio) {
        this.valorAnuncio = valorAnuncio;
    }
}

