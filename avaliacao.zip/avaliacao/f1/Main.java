package avaliacao.f1;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        Sponsors patrocinadorA = new Sponsors("Marlboro",250000.00);
        Sponsors patrocinadorB = new Sponsors("Monster",350000.00);
        var patrocinadoresEquipe = new ArrayList<Sponsors>();
        patrocinadoresEquipe.add(patrocinadorA);
        patrocinadoresEquipe.add(patrocinadorB);
        Team equipePrincipal = new Team("Ferrari",2000, patrocinadoresEquipe);

        Pilot pilotoPrincipal = new Pilot("Lewis Hamilton",31,"British",100);
        Pilot segundoPiloto = new Pilot("Charles Leclerc",28,"Monegasque",50);
        var pilotosDoEngenheiro = new ArrayList<Pilot>();
        pilotosDoEngenheiro.add(pilotoPrincipal);
        pilotosDoEngenheiro.add(segundoPiloto);
        Engineer engenheiroPrincipal = new Engineer("Carlo Santi", 52, "Italian", pilotosDoEngenheiro);
        Car carroPrincipal = new Car(10,1,equipePrincipal,pilotoPrincipal,engenheiroPrincipal);

        //Atribuição do carro que será mostrado
        Car carroExibido = carroPrincipal;
        System.out.println("Carro X:");

        //Print número do carro
        System.out.println("\tNúmero: " + carroExibido.getNumber());

        //Print da posição do carro
        System.out.println("\tPosição: " + carroExibido.getPosition());

        //Prints da equipe e seus atributos
        System.out.println("\tEquipe:\n\t\tNome: " + carroExibido.getTeam().getName() + "\n\t\tAno de fundação: " + carroExibido.getTeam().getFoundationYear());
        System.out.print("\t\tPatrocinadores:");
        for (Sponsors sponsor : carroExibido.getTeam().getSponsors()){
            System.out.print("\n\t\t\t" + sponsor.getName() + "\n\t\t\t\tValor de patrocínio: " + sponsor.getAdValue());
        }

        //Print do engenheiro e seus atributos
        System.out.println("\n\tEngenheiro:\n\t\tNome: " + carroExibido.getEngineer().getName() + "\n\t\tIdade: " + carroExibido.getEngineer().getAge() + "\n\t\tNacionalidade: " + carroExibido.getEngineer().getNationality() + "\n\t\tPilotos:");
        for (Pilot condutor : carroExibido.getEngineer().getPilotsOfTeam()){
            System.out.println("\t\t\t" + condutor.getName());
        }

        //Print do condutor e seus atributos
        System.out.println("\tPiloto:\n\t\tNome: " + carroExibido.getPilot().getName() + "\n\t\tIdade: " + carroExibido.getPilot().getAge() + "\n\t\tNacionalidade: " + carroExibido.getPilot().getNationality() + "\n\t\tNúmero de vitórias: " + carroExibido.getPilot().getVictory());

    }
}
