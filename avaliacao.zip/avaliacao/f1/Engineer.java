package avaliacao.f1;

import java.util.ArrayList;

public class Engineer extends Person{

    ArrayList<Pilot> pilotosEquipe;

    public Engineer(String name, int age, String nationality, ArrayList<Pilot> pilotosEquipe){
        super(name, age, nationality);
        this.pilotosEquipe=pilotosEquipe;
    }

    public ArrayList<Pilot> getPilotsOfTeam() {
        return pilotosEquipe;
    }

    public void setPilotsOfTeam(ArrayList<Pilot> pilotosEquipe) { this.pilotosEquipe = pilotosEquipe; }
}
