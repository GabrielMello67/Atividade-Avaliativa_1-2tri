package avaliacao.f1;

import java.util.ArrayList;

public class Team {

    private String nomeEquipe;
    private int anoFundacao;
    private ArrayList<Sponsors> listaPatrocinadores;

    public Team(String nomeEquipe, int anoFundacao, ArrayList<Sponsors> listaPatrocinadores){
        this.nomeEquipe=nomeEquipe;
        this.anoFundacao=anoFundacao;
        this.listaPatrocinadores=listaPatrocinadores;
    }

    public String getName() {
        return nomeEquipe;
    }

    public int getFoundationYear() {
        return anoFundacao;
    }

    public ArrayList<Sponsors> getSponsors() {
        return listaPatrocinadores;
    }

    public void setName(String nomeEquipe) {
        this.nomeEquipe = nomeEquipe;
    }

    public void setFoundationYear(int anoFundacao) {
        this.anoFundacao = anoFundacao;
    }

    public void setSponsors(ArrayList<Sponsors> listaPatrocinadores) {
        this.listaPatrocinadores = listaPatrocinadores;
    }
}
